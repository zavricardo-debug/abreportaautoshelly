// Spanish flow (peaje 2.0TD): values form, line-by-line comparison and results UI.
// Loaded by app.js; activated when the uploaded bill is detected as Spanish or when the
// user clicks "No tengo PDF (España)". All strings of this flow are in Spanish, the
// same words the bill uses (Potencia, Energía, Bono Social, Alquiler, Impuesto, IVA).
import { simulateES, simulateAllES, splitConsumption, cnmcLink, PERIODS_ES, PERIOD_LABELS_ES, RULES_ES_2026 } from './lib/simulator-es.js';
import { parseConsumptionCSV, sliceCurve, applyShare, shiftToValle, CALENDAR_TEXT_ES } from './lib/consumption-es.js';
import { sheetRowsToCsv } from './lib/xlsx-lite.js';
import { decodeCurveBuffer, parseAnySheet, previewOfDecoded } from './app-curve-pt.js';
import { hourlyRowsES, renderHourlySection } from './app-hourly.js';
import { loadCnmcMarket, loadCnmcOfferDetail } from './app-cnmc.js';
import { BRAND_LIST } from './lib/cnmc.js';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const fmtEur = (v, d = 2) => (v === null || v === undefined || Number.isNaN(v)) ? '—' : new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', minimumFractionDigits: d, maximumFractionDigits: d }).format(v);
const fmtNum = (v, d = 4) => (v === null || v === undefined || Number.isNaN(v)) ? '—' : new Intl.NumberFormat('es-ES', { minimumFractionDigits: d, maximumFractionDigits: d }).format(v);
const fmtDate = (iso) => iso ? new Date(iso).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' }) : '';
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const signed = (v, d = 2) => `${v < 0 ? '−' : v > 0 ? '+' : ''}${fmtEur(Math.abs(v), d)}`;
const r2 = (x) => Math.round((x + Number.EPSILON) * 100) / 100;

export const ES = { dataset: null, snapshot: null, live: null, liveError: null, liveKey: '', source: 'auto', parsed: null, form: null, baseline: null, results: [], rawText: '', curve: null, curveUsed: null, curveFile: '' };
let ui = { show: () => {}, hide: () => {}, showError: () => {}, hideError: () => {} };
const rules = () => ES.snapshot?.rules || RULES_ES_2026;

/* ------------------------------------------------------------------ boot */
export async function initES(hooks) {
  ui = { ...ui, ...hooks };
  // module state survives a re-import of app.js (tests boot several times): start clean
  Object.assign(ES, { dataset: null, snapshot: null, live: null, liveError: null, liveKey: '', liveLoading: false, parsed: null, form: null, baseline: null, results: [], rawText: '', curve: null, curveUsed: null, curveFile: '', curveText: '', curveForResults: null, shift: 0 });
  bindForm();
  bindFilters();
  bindCurve();
  try {
    const res = await fetch('data/ofertas-es.json', { cache: 'no-cache' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    ES.snapshot = await res.json();
    ES.dataset = ES.snapshot;
    $('#dataset-pill-es').textContent = `${ES.snapshot.meta.offers} tarifas ES · ${fmtDate(ES.snapshot.meta.publishedAt)}`;
    $('#dataset-date-es').textContent = fmtDate(ES.snapshot.meta.publishedAt);
    const sel = $('#es-supplier');
    const known = [...ES.snapshot.suppliers];
    for (const b of BRAND_LIST) if (b.code !== 'PVPC' && !known.some((k) => k.code === b.code)) known.push({ code: b.code, name: b.name });
    known.sort((a, b) => a.name.localeCompare(b.name, 'es'));
    for (const s of known) { const o = document.createElement('option'); o.value = s.code; o.textContent = s.name; sel.appendChild(o); }
    for (const [code, name] of [['PVPC', 'Comercializadora de referencia (PVPC)'], ['OTHER', 'Otra comercializadora']]) { const o = document.createElement('option'); o.value = code; o.textContent = name; sel.appendChild(o); }
    fillSupplierFilter(ES.snapshot.suppliers);
  } catch (e) {
    $('#dataset-pill-es').textContent = 'error tarifas ES';
    console.error('ofertas-es.json', e);
  }
}

function fillSupplierFilter(suppliers) {
  const fsel = $('#es-flt-supplier'); if (!fsel) return;
  const keep = fsel.value;
  fsel.innerHTML = '<option value="">Todas</option>';
  for (const s of suppliers) { const o = document.createElement('option'); o.value = s.code; o.textContent = s.name; fsel.appendChild(o); }
  fsel.value = suppliers.some((s) => s.code === keep) ? keep : '';
}

/* ------------------------------------------------------------------ market source (CNMC live / snapshot) */
/** Which dataset feeds the comparison: the live CNMC market when it loaded, otherwise the bundled snapshot. */
function activeDataset() {
  const want = $('#es-flt-source')?.value || 'auto';
  if (want !== 'snapshot' && ES.live) return ES.live;
  return ES.snapshot;
}
const liveKeyOf = (f) => JSON.stringify([f.power.p1, f.power.p2, f.days, f.kwh.punta, f.kwh.llano, f.kwh.valle, f.postalCode || '']);

/** Load the full CNMC market for the current profile (once per profile); re-renders when it arrives. */
async function loadLiveMarket(f) {
  const key = liveKeyOf(f);
  if (ES.liveKey === key && (ES.live || ES.liveLoading)) return;
  ES.liveKey = key; ES.live = null; ES.liveError = null; ES.liveLoading = true;
  setSourceStatus('loading', 'Consultando el comparador oficial de la CNMC (7 consultas, 20–60 s)…');
  try {
    const market = await loadCnmcMarket(profileOf(f), { cp: f.postalCode, onProgress: (n, t) => setSourceStatus('loading', `Consultando el comparador oficial de la CNMC… ${n}/${t}`) });
    if (ES.liveKey !== key) return;                       // the user changed the profile meanwhile
    ES.live = { ...market, rules: rules() };
    ES.liveLoading = false;
    if (ES.form) { computeResults(); renderResultsES(); }
  } catch (e) {
    if (ES.liveKey !== key) return;
    ES.liveLoading = false;
    ES.liveError = e?.message || String(e);
    console.warn('CNMC live', e);
    if (ES.form) renderResultsES();
  }
}

function setSourceStatus(kind, text) {
  const el = $('#es-source-status'); if (!el) return;
  el.className = `source-status ${kind}`;
  el.textContent = text;
}

/* ------------------------------------------------------------------ form */
export function showManualES() {
  ES.parsed = null;
  ES.rawText = '';
  fillFormES(null, '');
  $('#es-raw-text').textContent = '';
  ui.show('#step-values-es');
  $('#step-values-es').scrollIntoView({ behavior: 'smooth' });
}

const setVal = (sel, v, auto) => {
  const el = $(sel);
  el.value = (v === null || v === undefined || v === '' || Number.isNaN(v)) ? '' : +(+v).toFixed(7); // 7 decimals: the IE rate is 5,1126963 %
  el.classList.toggle('auto', !!auto && el.value !== '');
};

/** Fill the Spanish form from the parser output (or defaults when p is null = manual mode). */
export function fillFormES(p, rawText) {
  ES.parsed = p;
  ES.rawText = rawText || '';
  const R = rules();
  const cpTyped = $('#es-cp').value.trim() && !$('#es-cp').classList.contains('auto');   // typed by the user → kept
  $$('#values-form-es input').forEach((i) => i.classList.remove('auto'));
  $('#es-supplier-tag').textContent = p?.supplier ? `Factura ${p.supplier}${p.contractName ? ' · ' + p.contractName : ''}` : '';

  const p1 = p?.power?.p1 ?? p?.powerTerm?.p1?.kw ?? (p ? '' : 4.6);
  const p2 = p?.power?.p2 ?? p?.powerTerm?.p2?.kw ?? p1;
  setVal('#es-p1kw', p1, p); setVal('#es-p2kw', p2, p);
  setVal('#es-days', p?.days ?? 30, p && p.days);
  $('#es-period').value = p?.period ? `${fmtDate(p.period.start)} → ${fmtDate(p.period.end)}` : '';
  $('#es-period').dataset.start = p?.period?.start || '';
  $('#es-supplier').value = p?.supplierCode && $(`#es-supplier option[value="${p.supplierCode}"]`) ? p.supplierCode : (p?.supplierCode ? 'OTHER' : '');
  setVal('#es-pp1', p?.powerTerm?.p1?.price, p);
  setVal('#es-pp2', p?.powerTerm?.p2?.price ?? p?.powerTerm?.p1?.price, p);
  // postal code of the supply point (used for the CNMC query/deep link); a value typed by the user is kept
  if (p?.postalCode && !cpTyped) { $('#es-cp').value = p.postalCode; $('#es-cp').classList.add('auto'); }

  // energy
  const single = p ? !!p.energy?.single || !p.energy?.byPeriod || !Object.keys(p.energy.byPeriod).length : true;
  $('#es-single').checked = single;
  let kwh = { punta: '', llano: '', valle: '' };
  let hint = 'Introduzca el consumo de cada periodo (punta / llano / valle). Si su factura tiene precio único, el reparto sólo se usa para simular las tarifas con discriminación horaria.';
  if (p) {
    if (single) {
      const total = p.energy?.kwh || 0;
      const split = splitConsumption(total, p.energy?.readings, R.defaultSplit);
      kwh = { punta: r3(split.punta), llano: r3(split.llano), valle: r3(split.valle) };
      hint = p.energy?.readings
        ? `Consumo facturado ${fmtNum(total, 3)} kWh a precio único. Reparto por periodos según las lecturas de la factura (punta ${fmtNum(p.energy.readings.punta ?? 0, 0)} · llano ${fmtNum(p.energy.readings.llano ?? 0, 0)} · valle ${fmtNum(p.energy.readings.valle ?? 0, 0)} kWh) – sólo se usa para simular tarifas con discriminación horaria.`
        : `Consumo facturado ${fmtNum(total, 3)} kWh a precio único. La factura no indica el consumo por periodos: se usa un reparto estimado (${Math.round(R.defaultSplit.punta * 100)} / ${Math.round(R.defaultSplit.llano * 100)} / ${Math.round(R.defaultSplit.valle * 100)} %) para las tarifas con discriminación horaria – ajústelo si conoce sus consumos.`;
      setVal('#es-ep-single', p.energy?.price, p);
    } else {
      for (const k of PERIODS_ES) { kwh[k] = r3(p.energy.byPeriod[k]?.kwh || 0); setVal(`#es-ep-${k}`, p.energy.byPeriod[k]?.price, p); }
      hint = `Consumo facturado por periodos: ${PERIODS_ES.map((k) => `${PERIOD_LABELS_ES[k].toLowerCase()} ${fmtNum(kwh[k], 3)} kWh`).join(' · ')}.`;
      setVal('#es-ep-single', p.energy?.amount && p.energy?.kwh ? p.energy.amount / p.energy.kwh : null, false);
    }
  } else {
    setVal('#es-ep-single', '', false);
    for (const k of PERIODS_ES) setVal(`#es-ep-${k}`, '', false);
  }
  for (const k of PERIODS_ES) setVal(`#es-kwh-${k}`, kwh[k], p);
  $('#es-split-hint').textContent = hint;

  // regulated + taxes
  setVal('#es-bono', p?.bonoSocial?.price ?? R.bonoSocialPerDay, p && p.bonoSocial);
  setVal('#es-rent', p?.meterRent?.price ?? R.meterRentPerDay, p && p.meterRent);
  setVal('#es-ie', (p?.ie?.rate ?? R.ieRate) * 100, p && p.ie);
  setVal('#es-iva', (p?.iva?.rate ?? R.iva) * 100, p && p.iva);
  setVal('#es-other', p ? r2((p.discountAmount || 0) + (p.feeAmount || 0)) || '' : '', p && ((p.discountAmount || 0) !== 0 || (p.feeAmount || 0) !== 0));
  setVal('#es-services', p ? (p.serviceAmount || '') : '', p && (p.serviceAmount || 0) !== 0);
  // "Total de su factura" = what is paid: electricity invoice + a separate services invoice when the document has one
  setVal('#es-total', p?.totalToPay ?? p?.total, p && p.total !== null);

  // warnings / found lines
  const w = $('#es-parse-warnings'); w.innerHTML = '';
  if (p) {
    const labels = { power: 'Potencia', energy: 'Energía', bonoSocial: 'Financiación Bono Social', meterRent: 'Alquiler del contador', ie: 'Impuesto electricidad', iva: 'IVA' };
    const found = Object.keys(labels).filter((id) => p.items.some((it) => it.id === id));
    const missing = Object.keys(labels).filter((k) => !found.includes(k));
    const ok = document.createElement('div');
    ok.className = `alert ${missing.length > 2 ? 'warn' : 'ok'}`;
    ok.innerHTML = `<b>Factura española (2.0TD) · ${found.length} de 6 conceptos encontrados</b>: ${found.map((k) => labels[k]).join(', ') || '—'}.` +
      (missing.length ? `<br>No encontrados: ${missing.map((k) => labels[k]).join(', ')} – complete los valores manualmente si es necesario.` : '') +
      (p.total !== null ? (p.totalToPay ? ` Total a pagar: <b>${fmtEur(p.totalToPay)}</b> (factura de electricidad ${fmtEur(p.total)} + factura de servicios ${fmtEur(r2(p.totalToPay - p.total))}, fuera de la comparación).` : ` Total de la factura: <b>${fmtEur(p.total)}</b>.`) : '');
    w.appendChild(ok);
    if (p.warnings?.length) { const el = document.createElement('div'); el.className = 'alert warn'; el.innerHTML = `<ul>${p.warnings.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`; w.appendChild(el); }
  } else {
    const el = document.createElement('div'); el.className = 'alert info';
    el.textContent = 'Introduzca los valores tal como aparecen en su factura (precios sin impuestos). Los conceptos regulados ya vienen rellenados con los valores vigentes.';
    w.appendChild(el);
  }
  toggleSingle();
  if (ES.curve) applyCurveToForm();
  updateDerivedES();
}
const r3 = (v) => Math.round((v + Number.EPSILON) * 1000) / 1000;

/* ------------------------------------------------------------------ hourly consumption curve (CSV) */
function bindCurve() {
  const input = $('#es-curve-input'), drop = $('#es-curve-drop');
  if (!input) return;
  input.addEventListener('change', () => input.files[0] && handleCurveFile(input.files[0]));
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); drop.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); e.stopPropagation(); drop.classList.remove('drag'); }));
  drop.addEventListener('drop', (e) => { const f = e.dataTransfer.files?.[0]; if (f) handleCurveFile(f); });
  $('#btn-curve-sample').addEventListener('click', async (e) => {
    e.preventDefault(); e.stopPropagation();
    try {
      const res = await fetch('samples/consumo-horario-ejemplo.csv');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      loadCurveText(await res.text(), 'consumo-horario-ejemplo.csv');
    } catch (err) { curveError(`No se ha podido abrir la curva de ejemplo: ${err.message}`); }
  });
  $('#btn-curve-clear').addEventListener('click', () => { ES.curve = null; ES.curveUsed = null; ES.curveFile = ''; ES.curveText = ''; input.value = ''; $('#es-curve-result').classList.add('hidden'); $('#es-curve-error').classList.add('hidden'); fillFormES(ES.parsed, ES.rawText); });
  for (const id of ['#es-curve-use', '#es-curve-period', '#es-curve-ceuta']) $(id).addEventListener('change', () => { if (id === '#es-curve-ceuta' && ES.curveText) loadCurveText(ES.curveText, ES.curveFile); else { applyCurveToForm(); updateDerivedES(); } });
}
function curveError(msg, preview = '', sheetNames = null) {
  const el = $('#es-curve-error');
  el.textContent = msg;
  if (sheetNames && sheetNames.length > 1) { const p = document.createElement('div'); p.className = 'small'; p.textContent = `Hojas encontradas: ${sheetNames.join(', ')} (se han probado todas).`; el.appendChild(p); }
  if (preview) {
    const d = document.createElement('details'); d.className = 'err-preview';
    const sm = document.createElement('summary'); sm.textContent = 'Lo que se ha leído del fichero (primeras líneas)'; d.appendChild(sm);
    const pre = document.createElement('pre'); pre.textContent = preview; d.appendChild(pre);
    const hint = document.createElement('div'); hint.className = 'small muted'; hint.textContent = 'Si estas líneas no muestran fecha, hora y consumo, el fichero no es el detalle horario. Copie estas líneas para pedir soporte.'; d.appendChild(hint);
    el.appendChild(d);
  }
  el.classList.remove('hidden');
}

async function handleCurveFile(file) {
  $('#es-curve-error').classList.add('hidden');
  if (file.size > 40 * 1024 * 1024) return curveError('El fichero es demasiado grande (máx. 40 MB).');
  const buf = await file.arrayBuffer();
  loadCurveBufferES(buf, file.name);
}

/** CSV / TXT / XLSX / XLS bytes -> curve (Excel is read in the browser with lib/xlsx-lite.js / lib/xls-lite.js; every sheet is tried). */
export function loadCurveBufferES(buf, fileName = 'consumos.csv') {
  let dec = null;
  try {
    dec = decodeCurveBuffer(buf); // .xlsx / .xls (Excel 97-2003) / HTML-XML tables -> rows; otherwise text (UTF-8, UTF-16 or Windows-1252)
    if (!dec.rows) return loadCurveText(dec.text, fileName);
    const { curve, sheetName } = parseAnySheet(dec, (rows) => parseConsumptionCSV(sheetRowsToCsv(rows), { ceutaMelilla: $('#es-curve-ceuta').checked }));
    const sh = dec.sheets?.find((x) => x.name === sheetName);
    return loadCurveText(sheetRowsToCsv(sh ? sh.rows : dec.rows), fileName, curve);
  } catch (e) {
    console.error(e);
    ES.curve = null; ES.curveUsed = null;
    $('#es-curve-result').classList.add('hidden');
    curveError(`No se ha podido leer "${fileName}": ${e.message}`, dec ? previewOfDecoded(dec) : '', dec?.sheets?.map((x) => x.name));
    return null;
  }
}

/** Parse the CSV text, classify hours and apply to the form. Exposed for tests via window.__test_curve. */
export function loadCurveText(text, fileName = 'consumos.csv', parsedCurve = null) {
  try {
    const curve = parsedCurve || parseConsumptionCSV(text, { ceutaMelilla: $('#es-curve-ceuta').checked });
    ES.curve = curve; ES.curveText = text; ES.curveFile = fileName;
    $('#es-curve-error').classList.add('hidden');
    $('#es-curve-use').checked = true; // a freshly loaded curve is meant to be used
    applyCurveToForm();
    renderCurve();
    updateDerivedES();
    return curve;
  } catch (e) {
    ES.curve = null; ES.curveUsed = null;
    $('#es-curve-result').classList.add('hidden');
    curveError(`No se ha podido leer "${fileName}": ${e.message}`, previewOfDecoded({ text }));
    return null;
  }
}

/** Curve restricted to the billing period when requested and available. */
function curveForBill() {
  if (!ES.curve) return null;
  const p = ES.parsed;
  const wantPeriod = $('#es-curve-period').checked;
  if (wantPeriod && p?.period?.start && p?.period?.end) {
    const sl = sliceCurve(ES.curve, p.period.start, p.period.end, { endExclusive: true, ceutaMelilla: $('#es-curve-ceuta').checked });
    if (sl && sl.days >= 7) return { curve: sl, scope: 'period' };
  }
  return { curve: ES.curve, scope: 'all' };
}

/** Put the real punta/llano/valle kWh (scaled to the kWh of the bill) into the consumption inputs. */
function applyCurveToForm() {
  const sel = curveForBill();
  ES.curveUsed = sel;
  if (!sel || !$('#es-curve-use').checked) {
    if (ES.parsed) { // back to the bill's own split
      const p = ES.parsed; const total = p.energy?.kwh || 0;
      if (p.energy?.single !== false) { const split = splitConsumption(total, p.energy?.readings, rules().defaultSplit); for (const k of PERIODS_ES) setVal(`#es-kwh-${k}`, r3(split[k]), true); }
    }
    return;
  }
  const { curve, scope } = sel;
  const billKwh = ES.parsed?.energy?.kwh || null;
  // the bill's kWh are what was invoiced: the curve only provides the punta/llano/valle SHARES (its own total can
  // differ a little – estimated hours, meter vs. distributor data – and would otherwise change the energy amount)
  const kwh = billKwh ? applyShare(billKwh, curve.share) : curve.byPeriod;
  for (const k of PERIODS_ES) setVal(`#es-kwh-${k}`, r3(kwh[k]), true);
  const src = scope === 'period' ? `las ${curve.hours.length} horas de la curva dentro del periodo de la factura (${fmtDate(curve.start)} → ${fmtDate(curve.end)}, ${fmtNum(curve.totalKwh, 3)} kWh en el fichero)` : `la curva completa (${curve.days} días, ${fmtDate(curve.start)} → ${fmtDate(curve.end)})`;
  const gap = billKwh && scope === 'period' ? (curve.totalKwh - billKwh) / billKwh : 0;
  $('#es-split-hint').textContent = `Reparto REAL según ${src}: punta ${fmtNum(100 * curve.share.punta, 1)} % · llano ${fmtNum(100 * curve.share.llano, 1)} % · valle ${fmtNum(100 * curve.share.valle, 1)} %` +
    (billKwh ? ` aplicado a los ${fmtNum(billKwh, 3)} kWh facturados${Math.abs(gap) > 0.002 ? ` (el fichero suma ${fmtNum(curve.totalKwh, 3)} kWh, ${gap > 0 ? '+' : '−'}${fmtNum(100 * Math.abs(gap), 1)} %: se mantiene el consumo de la factura)` : ''}.` : '.') +
    ` ${CALENDAR_TEXT_ES}`;
}

/** Summary cards + two bar charts (average weekday / weekend profile coloured by period). */
function renderCurve() {
  const c = ES.curve; if (!c) return;
  const sel = curveForBill(); const cu = sel?.curve || c;
  $('#es-curve-result').classList.remove('hidden');
  const g = $('#es-curve-summary'); g.innerHTML = '';
  const bar = `<div class="period-bar" title="punta / llano / valle"><span class="punta" style="width:${(100 * cu.share.punta).toFixed(1)}%"></span><span class="llano" style="width:${(100 * cu.share.llano).toFixed(1)}%"></span><span class="valle" style="width:${(100 * cu.share.valle).toFixed(1)}%"></span></div>`;
  g.appendChild(sumCard('Fichero', esc(ES.curveFile), `${esc(c.format)}${c.cups ? ' · ' + esc(c.cups) : ''} · ${c.days} días (${fmtDate(c.start)} → ${fmtDate(c.end)})`, ''));
  g.appendChild(sumCard(sel?.scope === 'period' ? 'Consumo en el periodo de la factura' : 'Consumo de la curva', `${fmtNum(cu.totalKwh, 1)} kWh`, `${fmtNum(cu.totalKwh / Math.max(1, cu.days), 2)} kWh/día · ${cu.days} días${cu.estimatedShare ? ` · ${Math.round(cu.estimatedShare * 100)} % estimado` : ''}`, ''));
  g.appendChild(sumCard('Reparto real por periodos', `${fmtNum(100 * cu.share.punta, 0)} / ${fmtNum(100 * cu.share.llano, 0)} / ${fmtNum(100 * cu.share.valle, 0)} %`, `punta ${fmtNum(cu.byPeriod.punta, 1)} · llano ${fmtNum(cu.byPeriod.llano, 1)} · valle ${fmtNum(cu.byPeriod.valle, 1)} kWh${bar}`, ''));
  const billSplit = ES.parsed?.energy?.readings || null;
  const R = rules();
  const ref = billSplit ? splitConsumption(1, billSplit, R.defaultSplit) : R.defaultSplit;
  const refLabel = billSplit ? 'según las lecturas de la factura' : 'perfil estimado por defecto';
  g.appendChild(sumCard('Comparado con la factura', `${fmtNum(100 * ref.punta, 0)} / ${fmtNum(100 * ref.llano, 0)} / ${fmtNum(100 * ref.valle, 0)} %`, `${refLabel} · la curva ${cu.share.valle > ref.valle + 0.02 ? 'tiene MÁS consumo en valle: las tarifas con discriminación horaria le convienen más de lo que indicaba la factura' : cu.share.valle < ref.valle - 0.02 ? 'tiene MENOS consumo en valle: cuidado con las tarifas con discriminación horaria' : 'confirma el reparto de la factura'}`, cu.share.valle > ref.valle + 0.02 ? 'good' : cu.share.valle < ref.valle - 0.02 ? 'bad' : ''));
  if (c.warnings.length) { const w = document.createElement('div'); w.className = 'alert warn'; w.style.gridColumn = '1/-1'; w.innerHTML = `<ul>${c.warnings.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`; g.appendChild(w); }
  drawProfile($('#es-curve-weekday'), cu.profile.weekday, false);
  drawProfile($('#es-curve-weekend'), cu.profile.weekend, true);
}

function drawProfile(svg, values, weekend) {
  const W = 720, H = 200, padL = 34, padB = 22, padT = 8;
  const max = Math.max(0.1, ...values);
  const bw = (W - padL - 6) / 24;
  const ceuta = $('#es-curve-ceuta').checked;
  const per = (h) => weekend ? 'valle' : h < 8 ? 'valle' : ceuta ? (((h >= 11 && h < 15) || (h >= 19 && h < 23)) ? 'punta' : 'llano') : (((h >= 10 && h < 14) || (h >= 18 && h < 22)) ? 'punta' : 'llano');
  const yOf = (v) => padT + (H - padB - padT) * (1 - v / max);
  let out = '';
  for (const t of [0.25, 0.5, 0.75, 1]) { const y = yOf(max * t); out += `<line class="grid" x1="${padL}" x2="${W}" y1="${y.toFixed(1)}" y2="${y.toFixed(1)}"/><text x="2" y="${(y + 4).toFixed(1)}">${fmtNum(max * t, 2)}</text>`; }
  values.forEach((v, h) => {
    const x = padL + h * bw, y = yOf(v);
    out += `<rect class="${per(h)}" x="${(x + 1).toFixed(1)}" y="${y.toFixed(1)}" width="${(bw - 2).toFixed(1)}" height="${(H - padB - y).toFixed(1)}" rx="2"><title>${String(h).padStart(2, '0')}:00–${String(h + 1).padStart(2, '0')}:00 · ${fmtNum(v, 3)} kWh · ${per(h)}</title></rect>`;
    if (h % 2 === 0) out += `<text x="${(x + bw / 2 - 6).toFixed(1)}" y="${H - 6}">${String(h).padStart(2, '0')}</text>`;
  });
  svg.innerHTML = out;
}

function bindForm() {
  const f = $('#values-form-es');
  f.addEventListener('input', (e) => {
    e.target.classList.remove('auto');
    if (e.target.id === 'es-single') toggleSingle();
    updateDerivedES();
  });
  f.addEventListener('submit', (e) => { e.preventDefault(); runComparisonES(); });
}

function toggleSingle() {
  const single = $('#es-single').checked;
  $('#es-single-row').classList.toggle('hidden', !single);
  for (const k of PERIODS_ES) {
    const inp = $(`#es-ep-${k}`);
    inp.disabled = single; inp.required = !single;
    inp.closest('label').classList.toggle('hidden', single);
    $(`#es-o-e-${k}`).closest('label').classList.toggle('hidden', single);
  }
  $('#es-ep-single').required = single;
}

export function readFormES() {
  const num = (sel) => { const v = $(sel).value; return v === '' ? null : +v; };
  const kwh = {}; const energyPrice = {};
  for (const k of PERIODS_ES) { kwh[k] = num(`#es-kwh-${k}`) || 0; energyPrice[k] = num(`#es-ep-${k}`) || 0; }
  return {
    single: $('#es-single').checked,
    kwh, energyPrice, energySingle: num('#es-ep-single') || 0,
    power: { p1: num('#es-p1kw') || 0, p2: num('#es-p2kw') || num('#es-p1kw') || 0 },
    powerPrice: { p1: num('#es-pp1') || 0, p2: num('#es-pp2') || 0 },
    days: num('#es-days') || 30,
    bonoPerDay: num('#es-bono') ?? rules().bonoSocialPerDay,
    rentPerDay: num('#es-rent') ?? rules().meterRentPerDay,
    ieRate: (num('#es-ie') ?? rules().ieRate * 100) / 100,
    ivaRate: (num('#es-iva') ?? rules().iva * 100) / 100,
    curve: ES.curveUsed && $('#es-curve-use').checked ? { file: ES.curveFile, scope: ES.curveUsed.scope, share: ES.curveUsed.curve.share, days: ES.curveUsed.curve.days } : null,
    otherAmount: num('#es-other') || 0,
    servicesAmount: num('#es-services') || 0,
    invoiceTotal: num('#es-total'),
    supplierCode: $('#es-supplier').value || null,
    postalCode: ($('#es-cp').value || '').trim(),
    periodStart: $('#es-period').dataset.start || null,
  };
}
const profileOf = (f) => ({ days: f.days, power: f.power, kwh: f.kwh, meterRentPerDay: f.rentPerDay, bonoSocialPerDay: f.bonoPerDay, ieRate: f.ieRate, ivaRate: f.ivaRate });
const basePricesOf = (f) => ({ energy: f.single ? { single: f.energySingle } : { ...f.energyPrice }, power: { ...f.powerPrice }, otherAmount: f.otherAmount || 0, otherLabel: f.otherAmount < 0 ? 'Descuentos de su tarifa' : 'Cuotas de su tarifa' });
/** Optional services (maintenance, insurance…) are outside the electricity tariff: IVA only, no impuesto eléctrico. */
const servicesWithIva = (f) => r2((f.servicesAmount || 0) * (1 + (f.ivaRate ?? rules().iva)));

function updateDerivedES() {
  const f = readFormES();
  const totalKwh = PERIODS_ES.reduce((a, k) => a + f.kwh[k], 0);
  $('#es-o-kwh').textContent = `${fmtNum(totalKwh, 3)} kWh`;
  $('#es-o-pp1').textContent = fmtEur(f.power.p1 * f.powerPrice.p1 * f.days);
  $('#es-o-pp2').textContent = fmtEur(f.power.p2 * f.powerPrice.p2 * f.days);
  if (f.single) {
    $('#es-o-e-single').textContent = fmtEur(totalKwh * f.energySingle);
    $('#es-o-energy-total').textContent = fmtEur(totalKwh * f.energySingle);
  } else {
    let t = 0;
    for (const k of PERIODS_ES) { const a = f.kwh[k] * f.energyPrice[k]; t += a; $(`#es-o-e-${k}`).textContent = fmtEur(a); }
    $('#es-o-energy-total').textContent = fmtEur(t);
  }
  // reconstruction check
  const sim = simulateES(profileOf(f), basePricesOf(f), rules());
  const services = servicesWithIva(f);
  const reconstructed = r2(sim.total + services);
  const box = $('#es-check');
  const parts = `Potencia ${fmtEur(sim.powerAmount)} + Energía ${fmtEur(sim.energyAmount)}${sim.other ? ` ${sim.other < 0 ? '−' : '+'} Descuentos/cuotas ${fmtEur(Math.abs(sim.other))}` : ''} + Bono social ${fmtEur(sim.bonoSocial)} + Alquiler ${fmtEur(sim.meterRent)} + Impuesto electricidad ${fmtEur(sim.ie)} + IVA ${fmtEur(sim.iva)}${services ? ` + Servicios adicionales ${fmtEur(services)} (IVA incl.)` : ''}`;
  if (f.invoiceTotal) {
    const d = r2(reconstructed - f.invoiceTotal);
    box.className = `alert ${Math.abs(d) <= 0.05 ? 'ok' : 'warn'}`;
    box.innerHTML = `<b>Comprobación:</b> con estos valores la factura se reconstruye en <b>${fmtEur(reconstructed)}</b> (${parts}). Total de su factura: <b>${fmtEur(f.invoiceTotal)}</b>` +
      (Math.abs(d) <= 0.05 ? ' ✓ coincide: todos los conceptos de la factura están identificados.' : ` – diferencia de ${signed(d)}. Puede deberse a descuentos, servicios adicionales, regularizaciones u otros conceptos que no entran en la comparación; revise la tabla de abajo.`);
  } else {
    box.className = 'alert info';
    box.innerHTML = `<b>Factura reconstruida con estos valores:</b> ${fmtEur(reconstructed)} (${parts}).`;
  }
  renderBillLines(f, sim, services);
}

/** Step 2 table: every cost line of the uploaded bill (as read) next to the same line recomputed from the form values. */
function renderBillLines(f, sim, services) {
  const tb = $('#es-bill-lines tbody');
  if (!tb) return;
  const p = ES.parsed;
  const read = (v) => (v === null || v === undefined) ? '<span class="muted">—</span>' : fmtEur(v);
  const diffCell = (a, b) => {
    if (a === null || a === undefined || b === null || b === undefined) return '<td class="num diff"></td>';
    const d = r2(a - b);
    return `<td class="num diff ${Math.abs(d) <= 0.005 ? 'zero' : Math.abs(d) <= 0.02 ? 'zero' : 'bad'}">${Math.abs(d) <= 0.005 ? '=' : signed(d)}</td>`;
  };
  const row = (label, qty, price, readAmount, simAmount, cls = '') =>
    `<tr class="${cls}"><td>${label}</td><td>${qty}</td><td>${price}</td><td class="num">${read(readAmount)}</td><td class="num">${simAmount === null || simAmount === undefined ? '' : fmtEur(simAmount)}</td>${diffCell(simAmount, readAmount)}</tr>`;
  const rows = [];
  rows.push(row('Potencia P1 (punta-llano)', `${fmtNum(f.power.p1, 3)} kW × ${f.days} días`, `${fmtNum(f.powerPrice.p1, 6)} €/kW·día`, p?.powerTerm?.p1?.amount ?? null, sim.powerP1));
  rows.push(row('Potencia P2 / P3 (valle)', `${fmtNum(f.power.p2, 3)} kW × ${f.days} días`, `${fmtNum(f.powerPrice.p2, 6)} €/kW·día`, p?.powerTerm?.p2?.amount ?? null, sim.powerP2));
  if (f.single) {
    rows.push(row('Energía (precio único)', `${fmtNum(sim.totalKwh, 3)} kWh`, `${fmtNum(f.energySingle, 6)} €/kWh`, p?.energy?.amount ?? null, sim.energyAmount));
  } else {
    for (const k of PERIODS_ES) rows.push(row(`Energía ${PERIOD_LABELS_ES[k].toLowerCase()}`, `${fmtNum(f.kwh[k], 3)} kWh`, `${fmtNum(f.energyPrice[k], 6)} €/kWh`, p?.energy?.byPeriod?.[k]?.amount ?? null, sim.lines.find((l) => l.id === `energy_${k}`)?.amount ?? 0));
  }
  if (f.otherAmount) {
    // the lines behind the amount, as printed on the bill (e.g. "Aportación Regulada … Eficiencia Energética" = SNOEE contribution)
    const names = [...(p?.discounts || []), ...(p?.fees || [])].map((x) => x.label).filter(Boolean);
    rows.push(row(f.otherAmount < 0 ? 'Descuentos de su tarifa' : 'Cuotas de su tarifa', names.length ? `<span class="muted">${names.map((x) => esc(x.length > 100 ? x.slice(0, 60) + '…' + x.slice(-36) : x)).join(' · ')}</span>` : '', '', p ? r2((p.discountAmount || 0) + (p.feeAmount || 0)) : null, sim.other));
  }
  rows.push(row('Financiación Bono Social', `${f.days} días`, `${fmtNum(f.bonoPerDay, 6)} €/día`, p?.bonoSocial?.amount ?? null, sim.bonoSocial));
  rows.push(row('Alquiler del contador', `${f.days} días`, `${fmtNum(f.rentPerDay, 6)} €/día`, p?.meterRent?.amount ?? null, sim.meterRent));
  if (f.servicesAmount) rows.push(row('Servicios adicionales (fuera de la tarifa eléctrica)', '', 'sin impuesto eléctrico', p?.serviceAmount || null, r2(f.servicesAmount), 'muted'));
  rows.push(row('Impuesto electricidad', `s/ ${fmtEur(sim.ieBase)}`, `${fmtNum(f.ieRate * 100, 7)} %`, p?.ie?.amount ?? null, sim.ie));
  const servicesIva = r2(services - (f.servicesAmount || 0));
  // a separate services invoice prints its own IVA line: read = IVA of the electricity invoice + IVA of the services invoice
  const readIva = p?.iva?.amount === null || p?.iva?.amount === undefined ? null : r2(p.iva.amount + (p.servicesInvoice?.iva || 0));
  rows.push(row(`IVA ${Math.round(f.ivaRate * 100)} %`, `s/ ${fmtEur(r2(sim.ivaBase + (f.servicesAmount || 0)))}`, `${Math.round(f.ivaRate * 100)} %`, readIva, r2(sim.iva + servicesIva)));
  rows.push(row('TOTAL', '', '', f.invoiceTotal ?? p?.total ?? null, r2(sim.total + services), 'total'));
  tb.innerHTML = rows.join('');
}

/* ------------------------------------------------------------------ compare */
function runComparisonES() {
  if (!ES.snapshot) return ui.showError('La lista de tarifas españolas (data/ofertas-es.json) no se ha podido cargar.');
  ui.hideError();
  const f = readFormES();
  ES.form = f;
  ES.curveForResults = f.curve && ES.curveUsed ? { ...ES.curveUsed, file: ES.curveFile, ceutaMelilla: $('#es-curve-ceuta').checked } : null; // the hours behind the kWh of the form
  const profile = profileOf(f);
  ES.baseline = simulateES(profile, basePricesOf(f), rules());
  if (($('#es-flt-source')?.value || 'auto') !== 'snapshot') loadLiveMarket(f);   // async; re-renders when the CNMC answers
  computeResults();
  $('#es-cnmc-link').href = cnmcLink(profile, { postalCode: f.postalCode, periodStart: f.periodStart, contractType: f.single ? 'F0' : 'E0' });
  ui.show('#step-results-es');
  renderResultsES();
  $('#step-results-es').scrollIntoView({ behavior: 'smooth' });
}

function computeResults() {
  const f = ES.form;
  const includePromo = $('#es-flt-promo').checked;
  const shift = +($('#es-flt-shift')?.value || 0);
  const profile = profileOf(f);
  if (shift > 0) profile.kwh = shiftToValle(f.kwh, shift);
  ES.shift = shift;
  ES.dataset = activeDataset();
  fillSupplierFilter(ES.dataset.suppliers);
  ES.results = simulateAllES(ES.dataset, profile, { includePromo, currentSupplierCode: f.supplierCode });
  // welcome discounts are for new customers: an existing customer of that supplier gets the post-promo price
  for (const r of ES.results) {
    if (r.isCurrentSupplier && r.simAfter && includePromo) { r.sim = r.simAfter; r.promoDenied = true; }
  }
}

function bindFilters() {
  $$('#step-results-es .filters input, #step-results-es .filters select, #step-results-es .source-bar select').forEach((el) => el.addEventListener('change', () => {
    if (!ES.form) return;
    if (el.id === 'es-flt-source' && el.value !== 'snapshot') loadLiveMarket(ES.form);
    if (el.id === 'es-flt-promo' || el.id === 'es-flt-shift' || el.id === 'es-flt-source') computeResults();
    renderResultsES();
  }));
}

function filteredResultsES() {
  let r = ES.results;
  if ($('#es-flt-noindexed').checked) r = r.filter((x) => !x.offer.indexed);
  if ($('#es-flt-noservices')?.checked) r = r.filter((x) => !x.offer.servicesIncluded && !x.offer.permanence);
  r = r.filter((x) => !(x.offer.newClientsOnly && x.isCurrentSupplier));
  if (!$('#es-flt-newclient').checked) r = r.filter((x) => !x.offer.newClientsOnly);
  const sup = $('#es-flt-supplier').value;
  if (sup) r = r.filter((x) => x.offer.supplierCode === sup);
  if ($('#es-flt-best').checked) {
    const seen = new Set();
    r = r.filter((x) => { if (seen.has(x.offer.supplierCode)) return false; seen.add(x.offer.supplierCode); return true; });
  }
  r = [...r];
  const sort = $('#es-flt-sort').value;
  if (sort === 'energy') r.sort((a, b) => a.sim.energyAmount - b.sim.energyAmount);
  else if (sort === 'power') r.sort((a, b) => a.sim.powerAmount - b.sim.powerAmount);
  else if (sort === 'supplier') r.sort((a, b) => a.offer.supplier.localeCompare(b.offer.supplier, 'es') || a.sim.total - b.sim.total);
  else r.sort((a, b) => a.sim.total - b.sim.total);
  return r;
}

const regulatedOf = (s) => r2(s.bonoSocial + s.meterRent + (s.fee || 0) + (s.extra || 0) + (s.other || 0));

function renderResultsES() {
  const f = ES.form, base = ES.baseline;
  const rows = filteredResultsES();
  const totalKwh = base.totalKwh;
  const shifted = ES.shift ? shiftToValle(f.kwh, ES.shift) : null;
  $('#es-results-sub').textContent = `Perfil: ${fmtNum(f.power.p1, 2)} kW punta / ${fmtNum(f.power.p2, 2)} kW valle · ${fmtNum(totalKwh, 0)} kWh en ${f.days} días (punta ${fmtNum(f.kwh.punta, 0)} · llano ${fmtNum(f.kwh.llano, 0)} · valle ${fmtNum(f.kwh.valle, 0)}${f.curve ? ' – reparto REAL de su curva horaria' : ' – reparto estimado'})` +
    (shifted ? ` · simulando trasladar el ${Math.round(ES.shift * 100)} % de punta y llano a valle (punta ${fmtNum(shifted.punta, 0)} · llano ${fmtNum(shifted.llano, 0)} · valle ${fmtNum(shifted.valle, 0)} kWh)` : '') + ` · ${ES.results.length} tarifas aplicables.` +
    (f.curve ? ' En "Detalle" de cada tarifa verá el coste de la energía hora a hora con su consumo real.' : '');
  $('#es-th-days').textContent = `${f.days} días, con imp. · vs. su factura · al año`;

  const best = rows[0];
  const cheaper = rows.filter((x) => x.sim.total < base.total - 0.005).length;
  const sg = $('#es-summary-grid'); sg.innerHTML = '';
  const services = servicesWithIva(f);
  sg.appendChild(sumCard('Su factura (reconstruida)', fmtEur(base.total), `${fmtEur(base.totalPerYear, 0)}/año · energía media ${fmtNum(base.avgEnergyPrice, 4)} €/kWh · potencia ${fmtNum(base.avgPowerPerDay, 4)} €/día` + (f.invoiceTotal ? ` · factura real: ${fmtEur(f.invoiceTotal)}` : '') + (services ? ` (incluye ${fmtEur(services)} de servicios adicionales, fuera de la comparación)` : ''), ''));
  sg.appendChild(sumCard('Desglose de su factura', `${fmtEur(base.powerAmount + base.energyAmount)} <small>sin imp.</small>`, `potencia ${fmtEur(base.powerAmount)} · energía ${fmtEur(base.energyAmount)}${base.other ? ` · ${base.other < 0 ? 'descuentos' : 'cuotas'} ${fmtEur(base.other)}` : ''} · regulados ${fmtEur(r2(base.bonoSocial + base.meterRent))} · impuestos ${fmtEur(base.ie + base.iva)}`, ''));
  if (best) {
    const saving = base.total - best.sim.total;
    sg.appendChild(sumCard('Mejor tarifa', esc(best.offer.supplier), esc(best.offer.name) + (best.offer.promoText ? ' · con promoción' : ''), ''));
    sg.appendChild(sumCard(saving >= 0 ? 'Ahorro estimado' : 'Ya tiene una buena tarifa', signed(-saving), `${signed(-saving * 365 / f.days, 0)} al año · ${cheaper} tarifas más baratas que la suya`, saving > 0.5 ? 'good' : saving < -0.5 ? 'bad' : ''));
  }

  const tb = $('#es-results-table tbody'); tb.innerHTML = '';
  tb.appendChild(rowEl({ rank: '', name: 'Su factura actual', sub: `${supplierName(f.supplierCode)} · ${f.single ? fmtNum(f.energySingle, 6) + ' €/kWh' : PERIODS_ES.map((k) => fmtNum(f.energyPrice[k], 4)).join(' / ') + ' €/kWh'} · potencia ${fmtNum(f.powerPrice.p1, 6)} / ${fmtNum(f.powerPrice.p2, 6)} €/kW·día`, sim: base, base: null, cls: 'baseline', onDetail: () => openDetailES({ offer: { supplier: 'Su factura', name: 'Precios actuales' }, sim: base, prices: basePricesOf(f) }) }));
  rows.forEach((x, i) => {
    tb.appendChild(rowEl({ rank: i + 1, name: `${x.offer.supplier} · ${x.offer.name}`, sub: priceSub(x), badges: badges(x), sim: x.sim, base, cls: (i === 0 ? 'best ' : '') + (x.isCurrentSupplier ? 'current-supplier-es' : ''), onDetail: () => openDetailES(x) }));
  });
  const ds = ES.dataset, live = !!ds.meta.live;
  $('#es-results-count').textContent = `${rows.length} tarifas mostradas (de ${ES.results.length} aplicables a su perfil; ${ds.meta.offers} en la lista${live ? ` de la CNMC, ${ds.meta.suppliers} comercializadoras, consultada hoy` : `, actualizada el ${fmtDate(ds.meta.publishedAt)}`}).` +
    (live && ds.unpriced ? ` ${ds.unpriced} oferta${ds.unpriced > 1 ? 's' : ''} de la CNMC sin precios unitarios derivables (tramos o topes de consumo) no se muestra${ds.unpriced > 1 ? 'n' : ''}.` : '');
  renderSourceStatus();
  renderUnpriced();
  renderPeriodTable(rows);
}

/** Offers of the live CNMC list that cannot be rebuilt line by line (hours chosen by the customer, tranches…). */
function renderUnpriced() {
  const box = $('#es-unpriced'); if (!box) return;
  const un = (ES.dataset.offers || []).filter((o) => o.prices === false);
  box.classList.toggle('hidden', !un.length);
  if (!un.length) return;
  box.innerHTML = `<b>Otras ${un.length} ofertas registradas en la CNMC para su perfil</b> que no se pueden reconstruir concepto a concepto (el precio depende de las horas que elija el cliente, de tramos o de topes de consumo). Importe anual estimado por la CNMC con su consumo: ` +
    un.map((o) => `${esc(o.supplier)} · ${esc(o.name)} <b>${fmtEur(o.cnmc?.firstYear, 0)}/año</b>${o.cnmc?.secondYear && o.cnmc.secondYear !== o.cnmc.firstYear ? ` (2.º año ${fmtEur(o.cnmc.secondYear, 0)})` : ''}${o.servicesIncluded ? ' – con servicios' : ''}`).join('; ') + '.';
}

function renderSourceStatus() {
  const ds = ES.dataset;
  if (ds?.meta?.live) {
    const v = ds.meta.verified, n = ds.meta.priced;
    setSourceStatus('ok', `Mercado completo: ${ds.meta.offers} ofertas de ${ds.meta.suppliers} comercializadoras registradas en el comparador oficial de la CNMC para su perfil (${fmtNum(ds.meta.profile.p1, 2)}/${fmtNum(ds.meta.profile.p2, 2)} kW · ${fmtNum(ds.meta.profile.kwh.reduce((a, b) => a + b, 0), 0)} kWh/año${ds.meta.profile.cp ? ' · CP ' + ds.meta.profile.cp : ''}). Precios unitarios derivados del propio comparador; ${v} de ${n} reproducen al céntimo el importe anual que publica la CNMC.`);
  } else if (ES.liveLoading) {
    /* keep the progress text */
  } else if (ES.liveError && ($('#es-flt-source')?.value || 'auto') !== 'snapshot') {
    setSourceStatus('warn', `No se ha podido consultar el comparador de la CNMC (${ES.liveError}). Se muestra la lista guardada (${ES.snapshot.meta.offers} tarifas, ${fmtDate(ES.snapshot.meta.publishedAt)}); use el botón «Comprobar en el comparador oficial CNMC».`);
  } else {
    setSourceStatus('', `Lista guardada: ${ES.snapshot.meta.offers} tarifas de ${ES.snapshot.meta.suppliers} comercializadoras (${ES.snapshot.meta.source || 'CNMC'}, ${fmtDate(ES.snapshot.meta.publishedAt)}).`);
  }
}

/** Energy cost per 2.0TD period for every shown tariff (kWh of each period × its price) – the "horas valle / punta" view. */
function renderPeriodTable(rows) {
  const box = $('#es-period-box'); if (!box) return;
  const f = ES.form, base = ES.baseline;
  box.classList.remove('hidden');
  const kwh = ES.shift ? shiftToValle(f.kwh, ES.shift) : f.kwh;
  const total = PERIODS_ES.reduce((a, k) => a + kwh[k], 0) || 1;
  for (const k of PERIODS_ES) $(`#es-pt-${k}`).textContent = `${fmtNum(kwh[k], 0)} kWh · ${fmtNum(100 * kwh[k] / total, 0)} %`;
  $('#es-period-sub').textContent = (f.curve ? `Reparto real de su curva horaria (${f.curve.scope === 'period' ? 'periodo de la factura' : f.curve.days + ' días'})` : 'Reparto estimado de la factura') +
    (ES.shift ? ` con el ${Math.round(ES.shift * 100)} % de punta y llano trasladado a valle` : '') + ' · precios sin impuestos · las tarifas de precio único cobran lo mismo en todas las horas.';
  const tb = $('#es-period-table tbody'); tb.innerHTML = '';
  const priceOf = (pr, k) => pr.energy.punta != null ? pr.energy[k] : pr.energy.single;
  const rowHtml = (rank, name, prices, cls, baseEnergy) => {
    const amounts = PERIODS_ES.map((k) => kwh[k] * (priceOf(prices, k) || 0));
    const sum = amounts.reduce((x, y) => x + y, 0);
    return `<tr class="${cls}"><td class="rank">${rank}</td><td class="name" data-rank="${rank}"><div class="offer-name">${esc(name)}</div></td>` +
      PERIODS_ES.map((k, i) => `<td class="num" data-label="${PERIOD_LABELS_ES[k]}">${fmtEur(amounts[i])}<span class="p-price">${fmtNum(priceOf(prices, k) || 0, 4)} €/kWh</span></td>`).join('') +
      `<td class="num" data-label="Energía total"><b>${fmtEur(sum)}</b></td><td class="num" data-label="Precio medio €/kWh">${fmtNum(sum / total, 4)}</td>` +
      (baseEnergy === null ? '<td class="num" data-label="vs. su factura">—</td>' : `<td class="num diff ${sum - baseEnergy < -0.005 ? 'good' : sum - baseEnergy > 0.005 ? 'bad' : ''}" data-label="vs. su factura">${signed(r2(sum - baseEnergy))}</td>`) + '</tr>';
  };
  const basePrices = basePricesOf(f);
  const baseEnergy = PERIODS_ES.reduce((a, k) => a + kwh[k] * (priceOf(basePrices, k) || 0), 0);
  tb.insertAdjacentHTML('beforeend', rowHtml('', 'Su factura actual (precios de su tarifa)', basePrices, 'baseline', null));
  rows.forEach((x, i) => tb.insertAdjacentHTML('beforeend', rowHtml(i + 1, `${x.offer.supplier} · ${x.offer.name}`, x.prices, (i === 0 ? 'best ' : '') + (x.isCurrentSupplier ? 'current-supplier-es' : ''), baseEnergy)));
}

function supplierName(code) { return ES.dataset.suppliers.find((s) => s.code === code)?.name || ES.snapshot?.suppliers.find((s) => s.code === code)?.name || BRAND_LIST.find((b) => b.code === code)?.name || (code === 'PVPC' ? 'PVPC' : 'precios leídos de la factura'); }

function priceSub(x) {
  const p = x.prices;
  const e = p.energy.single != null && p.energy.punta == null ? `${fmtNum(p.energy.single, 4)} €/kWh` : `${PERIODS_ES.map((k) => fmtNum(p.energy[k], 4)).join(' / ')} €/kWh`;
  return `${e} · potencia ${fmtNum(p.power.p1, 4)} / ${fmtNum(p.power.p2, 4)} €/kW·día${p.feePerDay ? ` · gestión ${fmtNum(p.feePerDay, 3)} €/día` : p.feePerMonth ? ` · gestión ${fmtNum(p.feePerMonth, 2)} €/mes` : ''}`;
}

function badges(x) {
  const o = x.offer, b = [];
  if (o.indexed) b.push(['idx', 'indexada (precio de mercado)']);
  if (o.promoText && !x.promoDenied) b.push(['new', $('#es-flt-promo').checked ? 'promoción 1.er año' : 'promoción no aplicada']);
  if (x.promoDenied) b.push(['cond', 'sin promoción (ya es cliente)']);
  if (o.newClientsOnly) b.push(['cond', 'sólo nuevos clientes']);
  if (o.onlineOnly) b.push(['', 'contratación online']);
  if (o.priceFixedMonths) b.push(['fid', `precio fijo ${o.priceFixedMonths} meses`]);
  if (o.renewable) b.push(['green', '100 % renovable']);
  if (ES.form?.curve && o.energy?.punta != null) b.push(['curve', 'energía con su consumo real por horas']);
  if (o.maxKwhYear) b.push(['', `hasta ${fmtNum(o.maxKwhYear, 0)} kWh/año`]);
  if (o.maxPower && o.maxPower < 15) b.push(['', `hasta ${o.maxPower} kW`]);
  if (o.regulated) b.push(['dual', 'PVPC (tarifa regulada)']);
  if (o.servicesIncluded) b.push(['serv', 'incluye servicios adicionales']);
  if (o.permanence) b.push(['cond', o.penaltyEstimate ? `permanencia (penalización ≈ ${fmtEur(o.penaltyEstimate, 0)})` : 'con permanencia']);
  if (o.bonoSocialIncluded) b.push(['', 'bono social incluido en el precio']);
  if (o.cnmc?.verified) b.push(['cnmc', 'CNMC ✓ importe anual verificado']);
  else if (o.cnmc && o.cnmc.verified === false) b.push(['warn', `CNMC: desvío ${signed(o.cnmc.delta, 2)}/año`]);
  return b;
}

/** One cost cell: amount, delta vs. the same line of the bill underneath, optional extra block. `label` feeds the card layout (small screens). */
function cell(label, v, baseV, { bold = false, extra = '', cls = '' } = {}) {
  const d = baseV === null || baseV === undefined ? null : r2(v - baseV);
  const dHtml = d === null ? '' : `<span class="cell-delta ${d < -0.005 ? 'good' : d > 0.005 ? 'bad' : 'zero'}">${d === 0 ? '=' : signed(d)}</span>`;
  return `<td class="num${cls ? ' ' + cls : ''}" data-label="${esc(label)}">${bold ? '<b>' : ''}${fmtEur(v)}${bold ? '</b>' : ''}${dHtml}${extra}</td>`;
}

/** Energy of each 2.0TD period: what the bill's prices cost for those kWh vs. this tariff (kWh from the form / curve, what-if applied). */
function periodEnergyHtml(sim, base) {
  const f = ES.form; if (!f) return '';
  const bp = basePricesOf(f);
  const basePrice = (k) => bp.energy.punta != null ? +bp.energy[k] || 0 : +bp.energy.single || 0;
  const kwhOf = (k) => sim.kwh?.[k] || 0;
  const offerLine = (k) => sim.lines.find((l) => l.id === `energy_${k}`);
  const offerPrice = (k) => offerLine(k) ? +offerLine(k).price : +sim.lines.find((l) => l.id === 'energy_single')?.price || 0;
  const rows = PERIODS_ES.map((k) => {
    const kwh = kwhOf(k), now = r2(kwh * basePrice(k)), off = r2(kwh * offerPrice(k));
    const d = base ? r2(off - now) : null;
    return `<div class="pe-row"><span class="pe-k ${k}">${PERIOD_LABELS_ES[k]}</span><span class="pe-kwh">${fmtNum(kwh, 0)} kWh</span>` +
      (base ? `<span class="pe-now" title="con los precios de su factura">${fmtEur(now)}</span><span class="pe-arrow">→</span>` : '') +
      `<span class="pe-off">${fmtEur(off)}</span>` +
      (d === null ? '' : `<span class="pe-d ${d < -0.005 ? 'good' : d > 0.005 ? 'bad' : 'zero'}">${d === 0 ? '=' : signed(d)}</span>`) + '</div>';
  }).join('');
  return `<div class="period-energy${base ? '' : ' base'}">${rows}</div>`;
}

function rowEl(r) {
  const tr = document.createElement('tr');
  tr.className = r.cls || '';
  const s = r.sim, b = r.base;
  const diff = b ? r2(s.total - b.total) : null;
  const dcls = diff === null ? '' : diff < -0.005 ? 'good' : diff > 0.005 ? 'bad' : 'zero';
  // TOTAL cell = total · difference vs. the bill (like every other column) · annual figure (with its annual difference)
  const year = `<span class="cell-year">${fmtEur(s.totalPerYear, 0)}/año${diff === null ? '' : ` <span class="${dcls}">(${signed(diff * 365 / s.days, 0)})</span>`}</span>`;
  tr.innerHTML = `
    <td class="rank">${r.rank}</td>
    <td class="name" data-rank="${r.rank}"><div class="offer-name">${esc(r.name)}</div>${r.sub ? `<div class="offer-sub">${esc(r.sub)}</div>` : ''}${r.badges?.length ? `<div class="badges">${r.badges.map(([c, t]) => `<span class="badge ${c}">${esc(t)}</span>`).join('')}</div>` : ''}</td>
    ${cell('Potencia', s.powerAmount, b?.powerAmount)}
    ${cell('Energía', s.energyAmount, b?.energyAmount, { extra: periodEnergyHtml(s, b) })}
    ${cell('Otros conceptos', regulatedOf(s), b ? regulatedOf(b) : null)}
    ${cell('Impuesto eléctrico', s.ie, b?.ie)}
    ${cell('IVA', s.iva, b?.iva)}
    ${cell(`Total ${s.days} días`, s.total, b?.total, { bold: true, cls: 'total', extra: year })}
    <td class="act"><button type="button" class="btn ghost small">Detalle</button></td>`;
  $('button', tr).addEventListener('click', r.onDetail);
  return tr;
}

function sumCard(k, v, s, cls) {
  const el = document.createElement('div');
  el.className = `sum ${cls}`;
  el.innerHTML = `<div class="k">${k}</div><div class="v">${v}</div><div class="s">${s}</div>`;
  return el;
}

/* ------------------------------------------------------------------ detail modal */
function openDetailES(x) {
  const o = x.offer, s = x.sim, base = ES.baseline, isBase = s === base;
  $('#modal-title').textContent = `${o.supplier} – ${o.name}`;
  const qty = (l) => l.unit === 'kW' ? `${fmtNum(l.qty, 3)} kW × ${l.days} días` : l.unit === 'kWh' ? `${fmtNum(l.qty, 3)} kWh` : l.unit === 'días' ? `${l.days ?? l.qty} días` : l.unit === '€' ? `s/ ${fmtEur(l.qty)}` : l.id === 'other' ? '<span class="muted">importe fijo de su factura</span>' : '';
  const price = (l) => l.priceUnit === '%' ? `${fmtNum(l.price, l.id === 'ie' ? 7 : 0)} %` : l.price != null ? `${fmtNum(l.price, 6)} ${l.priceUnit}` : '';
  // energy per period with the prices of YOUR bill: a single-price bill costs kWh × precio único in every period,
  // so the user sees what the kWh consumed at those hours cost today vs. with this tariff
  const basePricesNow = basePricesOf(ES.form);
  const basePriceOf = (period) => period === 'single' ? (basePricesNow.energy.single ?? null) : (basePricesNow.energy.punta != null ? basePricesNow.energy[period] : basePricesNow.energy.single);
  const baseEnergyFor = (l) => {
    if (l.period === 'single') return base.energyAmount;
    if (!base.single) return base.lines.find((b) => b.id === l.id)?.amount ?? 0;
    return r2((l.qty || 0) * (basePriceOf(l.period) || 0));
  };
  const baseAmount = (l) => {
    if (isBase) return null;
    if (l.group === 'energy') return baseEnergyFor(l);
    return base.lines.find((b) => b.id === l.id)?.amount ?? 0;
  };
  const basePriceCell = (l) => {
    if (isBase || l.group !== 'energy') return '';
    const p = basePriceOf(l.period);
    return p == null ? '' : `<span class="muted small">${fmtNum(p, 6)} €/kWh${base.single && l.period !== 'single' ? ' (precio único)' : ''}</span>`;
  };
  const tr = (l) => {
    const b = baseAmount(l);
    const d = b === null || b === undefined ? null : r2(l.amount - b);
    return `<tr class="${l.group === 'total' ? 'total' : ''}"><td>${esc(l.label)}</td><td>${qty(l)}</td><td>${price(l)}</td>` +
      (isBase ? '' : `<td>${fmtEur(b)}${basePriceCell(l) ? '<br>' + basePriceCell(l) : ''}</td>`) +
      `<td>${fmtEur(l.amount)}</td>` +
      (isBase ? '' : `<td class="diff ${d === null ? '' : d < -0.005 ? 'good' : d > 0.005 ? 'bad' : ''}">${d === null ? '' : d === 0 ? '=' : signed(d)}</td>`) + '</tr>';
  };
  let lines = [...s.lines];
  // a single-price tariff compared with a 3-period bill: split its energy line by period (same price) so the rows line up
  if (!isBase && s.single && !base.single) {
    const price = +s.lines.find((l) => l.id === 'energy_single')?.price || 0;
    const per = PERIODS_ES.map((k) => ({ id: `energy_${k}`, group: 'energy', period: k, label: `Energía ${PERIOD_LABELS_ES[k].toLowerCase()}`, qty: s.kwh[k], unit: 'kWh', price, priceUnit: '€/kWh', amount: r2(s.kwh[k] * price) }));
    const i = lines.findIndex((l) => l.id === 'energy_single');
    lines.splice(i, 1, ...per);
  }
  // concepts that only exist on the user's bill (discounts / fees of the current tariff): show them with 0 for the offer
  if (!isBase) {
    for (const bl of base.lines.filter((l) => (l.id === 'other' || l.id === 'fee' || l.id === 'extra') && !lines.some((x) => x.id === l.id))) {
      const idx = lines.findIndex((l) => l.id === 'bono_social');
      lines.splice(idx < 0 ? lines.length : idx, 0, { ...bl, amount: 0, qty: null, price: null, priceUnit: '', unit: '' , label: `${bl.label} (sólo en su factura)` });
    }
  }
  // energy subtotal row when the offer has 3 periods (the bill may have a single price, so per-period deltas make no sense)
  const lastEnergy = lines.length - 1 - [...lines].reverse().findIndex((l) => l.group === 'energy');
  if (!isBase && lines.filter((l) => l.group === 'energy').length > 1) lines.splice(lastEnergy + 1, 0, { id: 'energy_total', group: 'energy_total', label: 'Energía (total)', amount: s.energyAmount, unit: 'kWh', qty: s.totalKwh, price: null });
  const rowsHtml = lines.map((l) => l.group === 'energy_total'
    ? `<tr class="subtotal"><td><i>${esc(l.label)}</i></td><td>${fmtNum(l.qty, 3)} kWh</td><td>${fmtNum(s.avgEnergyPrice, 6)} €/kWh (media)</td><td>${fmtEur(base.energyAmount)}<br><span class="muted small">${base.single ? `${fmtNum(basePriceOf('single'), 6)} €/kWh (precio único)` : `${fmtNum(base.avgEnergyPrice, 6)} €/kWh (media)`}</span></td><td>${fmtEur(l.amount)}</td><td class="diff ${l.amount - base.energyAmount < -0.005 ? 'good' : l.amount - base.energyAmount > 0.005 ? 'bad' : ''}">${signed(r2(l.amount - base.energyAmount))}</td></tr>`
    : tr(l)).join('');
  const table = `
    <table class="invoice">
      <thead><tr><th>Concepto</th><th>Cantidad</th><th>Precio (sin imp.)</th>${isBase ? '' : '<th>Su factura<br><small>lo que paga hoy</small></th>'}<th>${isBase ? 'Importe' : 'Esta tarifa'}</th>${isBase ? '' : '<th>Diferencia</th>'}</tr></thead>
      <tbody>${rowsHtml}</tbody>
    </table>`;
  const diffBox = !isBase ? `<div class="alert ${s.total <= base.total ? 'ok' : 'warn'}">${s.total <= base.total ? 'Ahorro' : 'Coste adicional'} respecto a su factura: <b>${fmtEur(Math.abs(s.total - base.total))}</b> en este periodo (${fmtEur(Math.abs(s.totalPerYear - base.totalPerYear), 0)}/año).${x.simAfter && x.simAfter !== s ? ` Cuando termine la promoción: <b>${fmtEur(x.simAfter.total)}</b> (${signed(r2(x.simAfter.total - base.total))}).` : ''}${x.promoDenied ? ' Como ya es cliente de esta comercializadora se aplican los precios sin la promoción de bienvenida.' : ''}</div>` : '';
  const typeName = { fixed: 'Precio fijo, único las 24 h', fixed3: 'Precio fijo con discriminación horaria (3 periodos)', indexed: 'Indexada al mercado mayorista (precio variable cada hora)', pvpc: 'PVPC – precio voluntario para el pequeño consumidor (tarifa regulada, precio horario)' }[o.type] || '—';
  const cnmcBlock = o.cnmc ? `<dt>Según la CNMC</dt><dd>Importe anual estimado por el comparador oficial para su perfil (${fmtNum(o.cnmc.profile?.p1 ?? ES.dataset.meta?.profile?.p1, 2)} kW · ${fmtNum((o.cnmc.profile?.kwh || ES.dataset.meta?.profile?.kwh || []).reduce((a, b) => a + b, 0), 0)} kWh/año): <b>${fmtEur(o.cnmc.firstYear)}</b> el 1.er año${o.cnmc.secondYear && o.cnmc.secondYear !== o.cnmc.firstYear ? ` · ${fmtEur(o.cnmc.secondYear)} el 2.º año` : ''}.` +
    (o.cnmc.ours != null ? ` Con los precios unitarios derivados reconstruimos ${fmtEur(o.cnmc.ours)} (${o.cnmc.verified ? 'coincide ✓' : 'desvío ' + signed(o.cnmc.delta)}).` : '') +
    ` Oferta n.º ${o.cnmcId}${o.cnmc.contracting?.length ? ' · contratación: ' + o.cnmc.contracting.join(', ') : ''}.</dd>` : '';
  const meta = o.id ? `
    <dl class="kv">
      <dt>Tipo</dt><dd>${typeName}</dd>
      ${o.promoText ? `<dt>Promoción</dt><dd>${esc(o.promoText)}${o.after ? ` · precios tras la promoción: ${o.after.energy?.single != null ? fmtNum(o.after.energy.single, 6) + ' €/kWh' : PERIODS_ES.map((k) => fmtNum(o.after.energy?.[k], 6)).join(' / ') + ' €/kWh'}` : ''}</dd>` : ''}
      <dt>Condiciones</dt><dd id="detail-conditions">${o.permanence ? 'Con permanencia' + (o.penaltyEstimate ? ` (penalización estimada ${fmtEur(o.penaltyEstimate)})` : '') : 'Sin permanencia'}${o.priceFixedMonths ? ` · precio fijo ${o.priceFixedMonths} meses` : ''}${o.onlineOnly ? ' · contratación sólo online' : ''}${o.newClientsOnly ? ' · sólo nuevos clientes' : ''}${o.servicesIncluded ? ` · incluye servicios adicionales${o.servicesText ? ' (' + esc(o.servicesText) + ')' : ''}` : ''}${o.maxPower ? ` · potencia hasta ${o.maxPower} kW` : ''}${o.maxKwhYear ? ` · consumo hasta ${fmtNum(o.maxKwhYear, 0)} kWh/año` : ''}${o.renewable ? ' · energía 100 % renovable' : ''}${o.bonoSocialIncluded ? ' · la financiación del bono social ya está incluida en los precios' : ''}${o.validity ? ' · ' + esc(o.validity) : ''}${o.priceRevision ? ' · revisión de precios: ' + esc(o.priceRevision) : ''}</dd>
      ${cnmcBlock}
      ${o.notes ? `<dt>Notas</dt><dd id="detail-notes">${esc(o.notes)}</dd>` : (o.cnmcId ? '<dt>Notas</dt><dd id="detail-notes" class="muted">Cargando las condiciones publicadas en la CNMC…</dd>' : '')}
      <dt>Fuente de los precios</dt><dd id="detail-source">${o.source?.url ? `<a href="${esc(o.source.url)}" target="_blank" rel="noopener">${esc(o.source.name)}</a>` : esc(o.source?.name || '—')} · consultado el ${fmtDate(o.source?.date)}.${o.source?.contract ? ` <a href="${esc(o.source.contract)}" target="_blank" rel="noopener">Condiciones del contrato</a>.` : ''} Los precios pueden haber cambiado: confirme siempre en la web de la comercializadora antes de contratar.</dd>
      <dt>Web</dt><dd class="links"><a href="${esc(ES.dataset.suppliers.find((sp) => sp.code === o.supplierCode)?.url || o.supplierUrl || o.source?.url || '#')}" target="_blank" rel="noopener">${esc(o.supplier)}</a><a href="${esc($('#es-cnmc-link').href)}" target="_blank" rel="noopener">Comparador CNMC</a></dd>
    </dl>` : `<p class="muted small">Reconstrucción de su factura con los precios leídos. Financiación del bono social y alquiler del contador son conceptos regulados idénticos en todas las tarifas.</p>`;
  $('#modal-body').innerHTML = diffBox + periodEnergyTableES(x, isBase) + table + hourlySectionES(x, isBase) + meta;
  $('#detail-modal').showModal();
  if (o.cnmcId && !o.notes && ES.form) fillDetailFromCnmc(o);
}

/** Live-market offers carry no conditions text until "Detalle" is opened: fetch the CNMC detail and fill the modal. */
async function fillDetailFromCnmc(o) {
  try {
    const d = await loadCnmcOfferDetail(o, profileOf(ES.form), { cp: ES.form.postalCode });
    Object.assign(o, { notes: d.notes || 'Sin condiciones adicionales publicadas.', validity: d.validity, priceRevision: d.priceRevision, maxPower: d.maxPower || o.maxPower, minPower: d.minPower || o.minPower, maxKwhYear: d.maxKwhYear || o.maxKwhYear });
    if (d.webOferta) o.source = { ...o.source, url: d.webOferta, contract: d.webContrato || o.source?.contract || null };
    if (d.contracting?.length) o.cnmc = { ...o.cnmc, contracting: d.contracting };
    const notes = $('#detail-notes'); if (!notes || $('#modal-title').textContent !== `${o.supplier} – ${o.name}`) return;
    notes.className = '';
    notes.innerHTML = esc(o.notes) + (d.infoAdicional ? `<br><span class="muted">${esc(d.infoAdicional)}</span>` : '') + (d.condicionesRevision ? `<br><span class="muted">Revisión de precios: ${esc(d.condicionesRevision)}</span>` : '');
    const cond = $('#detail-conditions');
    if (cond) cond.textContent += `${o.validity ? ' · ' + o.validity : ''}${o.priceRevision ? ' · revisión de precios: ' + o.priceRevision : ''}${o.maxKwhYear ? ` · consumo hasta ${fmtNum(o.maxKwhYear, 0)} kWh/año` : ''}${o.maxPower ? ` · potencia hasta ${o.maxPower} kW` : ''}`;
    const src = $('#detail-source');
    if (src && d.webOferta) src.innerHTML = `<a href="${esc(d.webOferta)}" target="_blank" rel="noopener">${esc(o.source.name)}</a> · consultado hoy.${d.webContrato ? ` <a href="${esc(d.webContrato)}" target="_blank" rel="noopener">Condiciones del contrato</a>.` : ''} Los precios pueden haber cambiado: confirme siempre en la web de la comercializadora antes de contratar.`;
  } catch (e) {
    const notes = $('#detail-notes'); if (notes) notes.textContent = `No se han podido cargar las condiciones desde la CNMC (${e?.message || e}).`;
  }
}

/** Detail modal: "Energía por periodo – lo que paga hoy vs. esta tarifa" (kWh of each 2.0TD period × both price sets). */
function periodEnergyTableES(x, isBase) {
  const f = ES.form, s = x.sim; if (!f || !s?.kwh) return '';
  const bp = basePricesOf(f);
  const priceNow = (k) => bp.energy.punta != null ? +bp.energy[k] || 0 : +bp.energy.single || 0;
  const priceOff = (k) => { const l = s.lines.find((q) => q.id === `energy_${k}`); return l ? +l.price : +s.lines.find((q) => q.id === 'energy_single')?.price || 0; };
  const rows = PERIODS_ES.map((k) => { const kwh = s.kwh[k] || 0; return { k, kwh, pn: priceNow(k), now: r2(kwh * priceNow(k)), po: priceOff(k), off: r2(kwh * priceOff(k)) }; }); // cents per line, like the bill
  const tot = rows.reduce((a, r) => ({ kwh: a.kwh + r.kwh, now: a.now + r.now, off: a.off + r.off }), { kwh: 0, now: 0, off: 0 });
  const dcell = (v) => `<td class="diff ${v < -0.005 ? 'good' : v > 0.005 ? 'bad' : 'zero'}">${v === 0 ? '=' : signed(v)}</td>`;
  const body = rows.map((r) => `<tr><td><span class="pe-k ${r.k}">${PERIOD_LABELS_ES[r.k]}</span></td><td>${fmtNum(r.kwh, 3)} kWh</td><td>${fmtNum(r.pn, 6)}${bp.energy.punta == null ? ' <span class="muted">(único)</span>' : ''}</td><td>${fmtEur(r.now)}</td>` +
    (isBase ? '' : `<td>${fmtNum(r.po, 6)}${s.single ? ' <span class="muted">(único)</span>' : ''}</td><td>${fmtEur(r.off)}</td>${dcell(r2(r.off - r.now))}`) + '</tr>').join('');
  const avgNow = bp.energy.punta == null ? `${fmtNum(+bp.energy.single || 0, 6)} <span class="muted">(único)</span>` : `${fmtNum(tot.kwh ? tot.now / tot.kwh : 0, 6)} <span class="muted">(media)</span>`;
  const avgOff = s.single ? `${fmtNum(priceOff('punta'), 6)} <span class="muted">(único)</span>` : `${fmtNum(tot.kwh ? tot.off / tot.kwh : 0, 6)} <span class="muted">(media)</span>`;
  const foot = `<tr class="total"><td>Total energía</td><td>${fmtNum(tot.kwh, 3)} kWh</td><td>${avgNow}</td><td>${fmtEur(r2(tot.now))}</td>` +
    (isBase ? '' : `<td>${avgOff}</td><td>${fmtEur(r2(tot.off))}</td>${dcell(r2(tot.off - tot.now))}`) + '</tr>';
  const src = f.curve ? `reparto REAL de su curva horaria (${f.curve.scope === 'period' ? 'periodo de la factura' : f.curve.days + ' días'})` : (ES.parsed?.energy?.readings ? 'lecturas por periodo de la factura' : 'reparto estimado por defecto');
  const note = `${isBase ? '' : bp.energy.punta == null ? ' Su tarifa tiene un precio único: "Paga hoy" es lo que le cuestan hoy los kWh consumidos en cada franja horaria.' : ''}${!isBase && ES.shift ? ` Incluye el escenario de trasladar el ${Math.round(ES.shift * 100)} % de punta y llano a valle (aplicado a ambos lados).` : ''}`;
  return `
    <h4 class="sub-h">Energía por periodo horario – ${isBase ? 'lo que paga hoy' : 'lo que paga hoy vs. esta tarifa'}</h4>
    <table class="invoice periods-cmp">
      <thead><tr><th>Periodo</th><th>kWh</th><th>Su tarifa<br><small>€/kWh sin imp.</small></th><th>Paga hoy</th>${isBase ? '' : '<th>Esta tarifa<br><small>€/kWh sin imp.</small></th><th>Con esta tarifa</th><th>Diferencia</th>'}</tr></thead>
      <tbody>${body}${foot}</tbody>
    </table>
    <p class="muted small">Importes sin impuestos. kWh por periodo: ${src}.${note}</p>`;
}

/** Hour-by-hour energy cost of this tariff vs. the bill's, from the consumption file used in the comparison (empty when there is none). */
function hourlySectionES(x, isBase) {
  const cf = ES.curveForResults, f = ES.form;
  if (!cf?.curve?.hours?.length || !f) return '';
  const curve = cf.curve;
  const billKwh = PERIODS_ES.reduce((a, k) => a + f.kwh[k], 0);
  const scale = curve.totalKwh > 0 && billKwh > 0 ? billKwh / curve.totalKwh : 1; // the form holds the billed kWh with the curve's shares
  const prices = isBase ? basePricesOf(f) : x.prices;
  const data = hourlyRowsES(curve.hours, { scale, shift: isBase ? 0 : ES.shift || 0, offer: prices, base: basePricesOf(f), ceutaMelilla: cf.ceutaMelilla });
  const scopeTxt = cf.scope === 'period' ? `las ${curve.hours.length} horas del fichero dentro del periodo de la factura (${fmtDate(curve.start)} → ${fmtDate(curve.end)})` : `el fichero completo (${curve.days} días, ${fmtDate(curve.start)} → ${fmtDate(curve.end)})`;
  const scaleTxt = Math.abs(scale - 1) > 0.001 ? ` Los kWh de cada hora están escalados a los ${fmtNum(billKwh, 0)} kWh facturados (× ${fmtNum(scale, 3)}), manteniendo el reparto real por horas.` : '';
  const shiftTxt = !isBase && ES.shift ? ` Incluye el escenario "trasladar el ${Math.round(ES.shift * 100)} % de punta y llano a valle" para esta tarifa (su factura se mantiene como está).` : '';
  const single = prices.energy?.punta == null;
  const intro = `Consumo de <b>${esc(cf.file)}</b>: ${scopeTxt}, ${data.dayCounts.weekday} laborables y ${data.dayCounts.weekend} de fin de semana/festivos. Cada hora se clasifica en punta / llano / valle según el calendario 2.0TD del día en que se consumió y se multiplica por el precio de ese periodo${single ? ' (esta tarifa tiene un precio único: todas las horas cuestan lo mismo por kWh)' : ''}.${scaleTxt}${shiftTxt}`;
  const note = 'Importes de energía sin impuestos (ni impuesto eléctrico ni IVA). La columna "Periodo" indica en qué periodo cae esa hora a lo largo de los días del fichero: 10–14 h es punta de lunes a viernes pero valle en fin de semana, por eso aparecen porcentajes. ' + CALENDAR_TEXT_ES;
  return renderHourlySection(data, { lang: 'es', isBase, intro, note, fmtNum, fmtEur, esc });
}
